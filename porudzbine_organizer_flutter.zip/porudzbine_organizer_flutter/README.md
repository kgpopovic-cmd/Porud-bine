# Porudžbine Organizer

Flutter Android aplikacija za unos i pregled porudžbina.

## Funkcije
- Dodavanje porudžbine
- Polja: kupac, telefon, proizvod, rok, cena, napomena
- Statusi: Nova, U izradi, Spremno, Isporučeno
- Pretraga po kupcu, telefonu, proizvodu i napomeni
- Filter po statusu
- Pregled ukupnog iznosa
- Pregled hitnih rokova
- Lokalno čuvanje porudžbina na telefonu preko SharedPreferences

## Pokretanje
```bash
flutter pub get
flutter run
```

## APK build
```bash
flutter build apk --release
```

APK će biti u:
```bash
build/app/outputs/flutter-apk/app-release.apk
```
