import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const OrdersApp());
}

enum OrderStatus {
  nova('Nova'),
  uIzradi('U izradi'),
  spremno('Spremno'),
  isporuceno('Isporučeno');

  const OrderStatus(this.label);
  final String label;

  static OrderStatus fromName(String name) {
    return OrderStatus.values.firstWhere(
      (status) => status.name == name,
      orElse: () => OrderStatus.nova,
    );
  }
}

class Order {
  Order({
    required this.id,
    required this.customer,
    required this.phone,
    required this.product,
    required this.deadline,
    required this.price,
    required this.note,
    required this.status,
    required this.createdAt,
  });

  final String id;
  final String customer;
  final String phone;
  final String product;
  final DateTime deadline;
  final double price;
  final String note;
  final OrderStatus status;
  final DateTime createdAt;

  Order copyWith({
    String? customer,
    String? phone,
    String? product,
    DateTime? deadline,
    double? price,
    String? note,
    OrderStatus? status,
  }) {
    return Order(
      id: id,
      customer: customer ?? this.customer,
      phone: phone ?? this.phone,
      product: product ?? this.product,
      deadline: deadline ?? this.deadline,
      price: price ?? this.price,
      note: note ?? this.note,
      status: status ?? this.status,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'customer': customer,
        'phone': phone,
        'product': product,
        'deadline': deadline.toIso8601String(),
        'price': price,
        'note': note,
        'status': status.name,
        'createdAt': createdAt.toIso8601String(),
      };

  static Order fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id'] as String,
      customer: json['customer'] as String,
      phone: json['phone'] as String,
      product: json['product'] as String,
      deadline: DateTime.parse(json['deadline'] as String),
      price: (json['price'] as num).toDouble(),
      note: json['note'] as String? ?? '',
      status: OrderStatus.fromName(json['status'] as String),
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }
}

class OrdersApp extends StatelessWidget {
  const OrdersApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Porudžbine',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        useMaterial3: true,
      ),
      home: const OrdersHomePage(),
    );
  }
}

class OrdersHomePage extends StatefulWidget {
  const OrdersHomePage({super.key});

  @override
  State<OrdersHomePage> createState() => _OrdersHomePageState();
}

class _OrdersHomePageState extends State<OrdersHomePage> {
  static const storageKey = 'orders_v1';

  final List<Order> _orders = [];
  final _searchController = TextEditingController();
  OrderStatus? _statusFilter;

  final _dateFormat = DateFormat('dd.MM.yyyy');
  final _currencyFormat = NumberFormat.currency(locale: 'sr_RS', symbol: 'RSD');

  @override
  void initState() {
    super.initState();
    _loadOrders();
    _searchController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadOrders() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(storageKey);
    if (raw == null) return;

    final decoded = jsonDecode(raw) as List<dynamic>;
    setState(() {
      _orders
        ..clear()
        ..addAll(decoded.map((item) => Order.fromJson(item as Map<String, dynamic>)));
    });
  }

  Future<void> _saveOrders() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      storageKey,
      jsonEncode(_orders.map((order) => order.toJson()).toList()),
    );
  }

  List<Order> get _filteredOrders {
    final query = _searchController.text.trim().toLowerCase();

    return _orders.where((order) {
      final matchesStatus = _statusFilter == null || order.status == _statusFilter;
      final matchesSearch = query.isEmpty ||
          order.customer.toLowerCase().contains(query) ||
          order.phone.toLowerCase().contains(query) ||
          order.product.toLowerCase().contains(query) ||
          order.note.toLowerCase().contains(query);

      return matchesStatus && matchesSearch;
    }).toList()
      ..sort((a, b) => a.deadline.compareTo(b.deadline));
  }

  double get _totalAmount =>
      _filteredOrders.fold(0, (sum, order) => sum + order.price);

  int get _urgentCount {
    final today = DateTime.now();
    final limit = DateTime(today.year, today.month, today.day).add(const Duration(days: 2));

    return _orders.where((order) {
      final deadline = DateTime(order.deadline.year, order.deadline.month, order.deadline.day);
      return order.status != OrderStatus.isporuceno && deadline.isBefore(limit.add(const Duration(days: 1)));
    }).length;
  }

  Future<void> _openOrderForm({Order? existing}) async {
    final result = await showModalBottomSheet<Order>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => OrderFormSheet(order: existing),
    );

    if (result == null) return;

    setState(() {
      final index = _orders.indexWhere((order) => order.id == result.id);
      if (index >= 0) {
        _orders[index] = result;
      } else {
        _orders.add(result);
      }
    });
    await _saveOrders();
  }

  Future<void> _deleteOrder(Order order) async {
    setState(() => _orders.removeWhere((item) => item.id == order.id));
    await _saveOrders();
  }

  Future<void> _changeStatus(Order order, OrderStatus status) async {
    final updated = order.copyWith(status: status);
    setState(() {
      final index = _orders.indexWhere((item) => item.id == order.id);
      if (index >= 0) _orders[index] = updated;
    });
    await _saveOrders();
  }

  bool _isUrgent(Order order) {
    if (order.status == OrderStatus.isporuceno) return false;
    final today = DateTime.now();
    final todayOnly = DateTime(today.year, today.month, today.day);
    final deadline = DateTime(order.deadline.year, order.deadline.month, order.deadline.day);
    return !deadline.isAfter(todayOnly.add(const Duration(days: 2)));
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filteredOrders;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Porudžbine'),
        actions: [
          IconButton(
            tooltip: 'Dodaj porudžbinu',
            onPressed: () => _openOrderForm(),
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openOrderForm(),
        icon: const Icon(Icons.add),
        label: const Text('Nova porudžbina'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            _SummaryCards(
              total: _currencyFormat.format(_totalAmount),
              urgentCount: _urgentCount,
              orderCount: filtered.length,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  labelText: 'Pretraga',
                  hintText: 'Kupac, telefon, proizvod ili napomena',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _searchController.text.isEmpty
                      ? null
                      : IconButton(
                          onPressed: _searchController.clear,
                          icon: const Icon(Icons.clear),
                        ),
                  border: const OutlineInputBorder(),
                ),
              ),
            ),
            SizedBox(
              height: 48,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FilterChip(
                      selected: _statusFilter == null,
                      label: const Text('Sve'),
                      onSelected: (_) => setState(() => _statusFilter = null),
                    ),
                  ),
                  ...OrderStatus.values.map(
                    (status) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: FilterChip(
                        selected: _statusFilter == status,
                        label: Text(status.label),
                        onSelected: (_) => setState(() => _statusFilter = status),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: filtered.isEmpty
                  ? const Center(
                      child: Text('Nema porudžbina za izabrane filtere.'),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                      itemCount: filtered.length,
                      itemBuilder: (context, index) {
                        final order = filtered[index];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          child: ListTile(
                            onTap: () => _openOrderForm(existing: order),
                            title: Text(order.product),
                            subtitle: Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('${order.customer} • ${order.phone}'),
                                  Text('Rok: ${_dateFormat.format(order.deadline)}'),
                                  if (order.note.isNotEmpty) Text('Napomena: ${order.note}'),
                                ],
                              ),
                            ),
                            leading: CircleAvatar(
                              child: Text(order.customer.isNotEmpty ? order.customer[0].toUpperCase() : '?'),
                            ),
                            trailing: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(_currencyFormat.format(order.price)),
                                const SizedBox(height: 4),
                                _StatusMenu(
                                  status: order.status,
                                  onChanged: (status) => _changeStatus(order, status),
                                ),
                                if (_isUrgent(order))
                                  const Text(
                                    'Hitno',
                                    style: TextStyle(fontWeight: FontWeight.bold),
                                  ),
                              ],
                            ),
                            isThreeLine: true,
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryCards extends StatelessWidget {
  const _SummaryCards({
    required this.total,
    required this.urgentCount,
    required this.orderCount,
  });

  final String total;
  final int urgentCount;
  final int orderCount;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Row(
        children: [
          Expanded(
            child: _SummaryCard(
              title: 'Ukupno',
              value: total,
              icon: Icons.payments,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _SummaryCard(
              title: 'Hitni rokovi',
              value: urgentCount.toString(),
              icon: Icons.warning_amber,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _SummaryCard(
              title: 'Prikazano',
              value: orderCount.toString(),
              icon: Icons.receipt_long,
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Icon(icon),
            const SizedBox(height: 6),
            Text(title, textAlign: TextAlign.center),
            const SizedBox(height: 4),
            Text(
              value,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusMenu extends StatelessWidget {
  const _StatusMenu({
    required this.status,
    required this.onChanged,
  });

  final OrderStatus status;
  final ValueChanged<OrderStatus> onChanged;

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<OrderStatus>(
      tooltip: 'Promeni status',
      onSelected: onChanged,
      itemBuilder: (context) => OrderStatus.values
          .map(
            (item) => PopupMenuItem(
              value: item,
              child: Text(item.label),
            ),
          )
          .toList(),
      child: Chip(
        label: Text(status.label),
        visualDensity: VisualDensity.compact,
      ),
    );
  }
}

class OrderFormSheet extends StatefulWidget {
  const OrderFormSheet({super.key, this.order});

  final Order? order;

  @override
  State<OrderFormSheet> createState() => _OrderFormSheetState();
}

class _OrderFormSheetState extends State<OrderFormSheet> {
  final _formKey = GlobalKey<FormState>();
  final _customer = TextEditingController();
  final _phone = TextEditingController();
  final _product = TextEditingController();
  final _price = TextEditingController();
  final _note = TextEditingController();

  late DateTime _deadline;
  late OrderStatus _status;

  final _dateFormat = DateFormat('dd.MM.yyyy');

  @override
  void initState() {
    super.initState();
    final order = widget.order;

    _customer.text = order?.customer ?? '';
    _phone.text = order?.phone ?? '';
    _product.text = order?.product ?? '';
    _price.text = order == null ? '' : order.price.toStringAsFixed(0);
    _note.text = order?.note ?? '';
    _deadline = order?.deadline ?? DateTime.now().add(const Duration(days: 3));
    _status = order?.status ?? OrderStatus.nova;
  }

  @override
  void dispose() {
    _customer.dispose();
    _phone.dispose();
    _product.dispose();
    _price.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickDeadline() async {
    final selected = await showDatePicker(
      context: context,
      initialDate: _deadline,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
    );

    if (selected != null) {
      setState(() => _deadline = selected);
    }
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;

    final old = widget.order;
    final normalizedPrice = _price.text.replaceAll(',', '.');

    final order = Order(
      id: old?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      customer: _customer.text.trim(),
      phone: _phone.text.trim(),
      product: _product.text.trim(),
      deadline: _deadline,
      price: double.tryParse(normalizedPrice) ?? 0,
      note: _note.text.trim(),
      status: _status,
      createdAt: old?.createdAt ?? DateTime.now(),
    );

    Navigator.of(context).pop(order);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Form(
        key: _formKey,
        child: ListView(
          shrinkWrap: true,
          children: [
            Text(
              widget.order == null ? 'Nova porudžbina' : 'Izmena porudžbine',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _customer,
              decoration: const InputDecoration(
                labelText: 'Kupac',
                border: OutlineInputBorder(),
              ),
              validator: (value) =>
                  value == null || value.trim().isEmpty ? 'Unesi kupca' : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _phone,
              decoration: const InputDecoration(
                labelText: 'Telefon',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.phone,
              validator: (value) =>
                  value == null || value.trim().isEmpty ? 'Unesi telefon' : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _product,
              decoration: const InputDecoration(
                labelText: 'Proizvod',
                border: OutlineInputBorder(),
              ),
              validator: (value) =>
                  value == null || value.trim().isEmpty ? 'Unesi proizvod' : null,
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _price,
              decoration: const InputDecoration(
                labelText: 'Cena',
                border: OutlineInputBorder(),
                prefixText: 'RSD ',
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: (value) {
                if (value == null || value.trim().isEmpty) return 'Unesi cenu';
                final parsed = double.tryParse(value.replaceAll(',', '.'));
                return parsed == null ? 'Cena nije ispravna' : null;
              },
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<OrderStatus>(
              value: _status,
              decoration: const InputDecoration(
                labelText: 'Status',
                border: OutlineInputBorder(),
              ),
              items: OrderStatus.values
                  .map(
                    (status) => DropdownMenuItem(
                      value: status,
                      child: Text(status.label),
                    ),
                  )
                  .toList(),
              onChanged: (value) => setState(() => _status = value ?? OrderStatus.nova),
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: _pickDeadline,
              icon: const Icon(Icons.calendar_month),
              label: Text('Rok: ${_dateFormat.format(_deadline)}'),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _note,
              decoration: const InputDecoration(
                labelText: 'Napomena',
                border: OutlineInputBorder(),
              ),
              minLines: 2,
              maxLines: 4,
            ),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: const Text('Sačuvaj'),
            ),
          ],
        ),
      ),
    );
  }
}
